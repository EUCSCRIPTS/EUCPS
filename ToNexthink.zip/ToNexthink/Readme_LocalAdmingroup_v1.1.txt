###########################################################################################

# Author      : Venkatesh Sriram

# Requested By: Requestor Name + Incident Number

# Description : This script will remotely add the AD Groups or AD Users to the Local 
	        Administrator Group of the windows 10 Device as per the given input file.

# Input       : The input is a text file where it contains user samaccountname or
		AD Group Name object along with the devicename. Refer to the available input template on the same folder.
		Name of the file should be 'LocalAdminInput'

# Output      : The Users SAMAccountName or AD Group will be added to Local administrator group of that given deviceand the
		steps are logged.

# Version     : 1.0 - Initial Version - Logic Added only add AD groupname to Local Administrator Group.
		1.1 - Added logic to add AD Users - Done By Venkatesh

# Approved By : EUC Manager

# Pre-Requisite : The script will exit if it is unable to create a Log folder or Log File.
		  AD Module to be available on the script execution device
		  Machines should be avaialble on the network. Offline devices will be logged.
		  IT Member who executes the script should have required administrator rights on the device.

# Instructions: a. Copy the script and Readme file to the desired location on the executing device.
		b. Get ready with the input file in the place(same location from where script executes).
		c. Launch Powershell ISE with Admin credentials
		d. Check for availability AD Module using "Get-InstalledModule ActiveDirectory" command.
		e. Navigate to script file location
		f. Execute it.
		g. Log file will be generated on the same location from where script is executed.

# Contact Team : Desktop Operations Team

#################################################################################################################
