###########################################################################################

# Author      : Venkatesh Sriram

# Requestor   : Client Name + Incident Number

# Description : This script will add the AD Groups or AD Users to the Local 
	        Administrator Group of the windows 10 Device as per the given input.

# Input       : The input is a text file where it contains either the user object or
		AD Group object.

# Output      : The Users or AD Group will be added to Local administrator group and the
		steps are logged.

# Version     : 1.0 - Initial Version
		1.1 - Added Condition to add AD Users - Done By Venkatesh

# Approved By : EUC Manager

# Pre-Requisite : AD Module to be available on the script execution device

# Instructions: a. Get ready with the input file in the place.
		b. Check for AD Module
		c. Launch Powershell ISE with Admin credentials
		d. Naviagate to script file location
		e. Execute it.
		f. Log file will be generated on the same location from where script is
		   executed.

# Contact Team : Desktop Operations Team
