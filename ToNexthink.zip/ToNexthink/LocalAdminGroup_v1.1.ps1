﻿#############################################################################################################################################
#### 
#### Script:      LocalAdminGroup_v1.1.ps1                                      
#### Author:      Venkatesh Sriram                                            
#### Version:     1.0                                                         
#### Description: Remotely Adding AD groups/AD Users to Local Administrator group to the list of given machines 
####              as per input file.
#### Approver:    EUC Manager
####
#### Changes:     1.1 - Added the logic to add AD Users to local admin group
####
##############################################################################################################################################

######## Deriving the  Log File at the same location from where the script executes ##############

$CurrentPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
 
$LogPath = Join-Path -Path $CurrentPath -ChildPath 'Logs'
 
$LogRootName = (Split-Path -Path $MyInvocation.MyCommand.Path -Leaf) -replace '\.ps1'
 
$TimeStamp = Get-Date -Format yyyyMMdd_HHmmss
 
$LogFileName = '{0}_{1}.log' -f $LogRootName, $TimeStamp
 
$LogFile = Join-Path -Path $LogPath -ChildPath $LogFileName


########## Creation of Logs Folder if does not exists. Script will exit if Log folder creation fails ##############

if (!(Test-Path $LogPath)) 
{ 
    if(New-Item -Path $LogPath -ItemType Directory -Verbose)
    {
        Write-Verbose "Created the Log Directory Successfully"
    }
    else
    {
        exit
    }
} 

########## Creation of Logs File if does not exists. Script will exit if Log file creation fails ##############

if (!(Test-Path $LogFile)) 
{ 
    Write-Verbose "Creating $LogFile."
    $NewLogFile = New-Item $LogFile -Force -ItemType File
    if($NewLogFile)
    {
        Write-Verbose "Log File created successfully"
    }
    else
    {
        exit
    }

} 

######## A Function written to populate the log file. ##############

function populate-LogMessage
{
    param($Message)
    
    ((Get-Date).ToString() + " - " + $Message) >> $LogFile;
}


<######## Input text file which contains Machine Names and AD Groups/AD UserSamaccount Name.
 The input should have first row as heading MachineName ADGroup. Refer to the attached input template file. #####>

$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$inputPath = Join-Path $executingScriptDirectory "LocalAdminInput.txt"
$devicedata = Get-Content $inputPath

######## Add AD group/AD User to Local Administrator group for all given devices from the input file ##############

foreach($device in $devicedata)
{
   
    $device = $device.split(',')
    $ComputerName = $device[0]
    $adobj = $device[1]
       
    if(Test-Connection -BufferSize 32 -Count 1 -ComputerName $ComputerName -Quiet)
    {
        populate-LogMessage("Started Processing $ComputerName ")
        try
        {
            $userobj = Get-ADUser -LDAPFilter "(SAMAccountName=$adobj)" #Returns null if it is a AD Group Object
            $grpobj = Get-ADGroup -LDAPFilter "(SAMAccountName=$adobj)" #Returns null if it is a AD User Object

            ################### Adds AD group to the Local Administrator Group ############################
            if($grpobj -ne $null)
            {
                $adgroupname = $grpobj.Name
                $ADGroup = Get-ADGroup $adgroupname -Properties *
                $grpname = $ADGroup.Name #results as AD object
                $Domain =  $ADGroup.CanonicalName.Split("/")[0]        
                $LocalAdminGroup = [ADSI]"WinNT://$ComputerName/Administrators,group"
            
                $GroupObj = [ADSI]"WinNT://$Domain/$grpname,group"

                Try
                {
                    $LocalAdminGroup.Add($GroupObj.Path)
                    populate-LogMessage("Group $Domain\$grpname has been added to local admin group on computer $ComputerName")
                }
                Catch
                {
                    $Exception = ($_.Exception.Message).Split(":")[1].replace("account","group")
                
                    populate-LogMessage("ERROR: ADGroup: $Domain\$grpname Computer: $ComputerName $Exception")
                }
            }
            ################### Adds AD User to the Local Administrator Group ############################
            if($userobj -ne $null)
            {
                $adusername = $userobj.Name
                $ADUser = Get-ADuser $adusername -Properties *
                $username = $ADUser.Name
                $Domain =  $ADUser.CanonicalName.Split("/")[0]        
                $LocalAdminGroup = [ADSI]"WinNT://$ComputerName/Administrators,group"
            
                $GroupObj = [ADSI]"WinNT://$Domain/$username,user"

                Try
                {
                    $LocalAdminGroup.Add($GroupObj.Path)
                    populate-LogMessage("User $Domain\$username has been aded to local admin group on computer $ComputerName")
                }
                Catch
                {
                    $Exception = ($_.Exception.Message).Split(":")[1].replace("account","user")
                
                    populate-LogMessage("ERROR: ADUser: $Domain\$username Computer: $ComputerName $Exception")
                }  
            }
        }
        catch 
        {
             $Exception = ($_.Exception.Message).Split(":")[1]
             populate-LogMessage($Exception)
        }
    }
    else
    {
        populate-LogMessage("ERROR: Device $ComputerName is Offline")
    }    
}
