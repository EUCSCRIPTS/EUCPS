﻿#############################################################################################################################################
#### 
#### Script:      LocalAdminGroup.ps1                                      
#### Author:      Venkatesh Sriram                                            
#### Version:     1.0                                                         
#### Description: Adding AD groups/AD Users to Local Administrator group as per the given input.
#### Approver:    EUC Manager
####
#### Changes:     1.1 - Added Condition to add AD Users to local admin group
####
##############################################################################################################################################

######## Creation of Log File at the same location from where the script executes ##############
$CurrentPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent 
 
$LogPath = Join-Path -Path $CurrentPath -ChildPath 'Logs'
 
$LogRootName = (Split-Path -Path $MyInvocation.MyCommand.Path -Leaf) -replace '\.ps1'
 
$TimeStamp = Get-Date -Format yyyyMMdd_HHmmss
 
$LogFileName = '{0}_{1}.log' -f $LogRootName, $TimeStamp
 
$LogFile = Join-Path -Path $LogPath -ChildPath $LogFileName


########## Creation of Logs Folder if does not exists ##############

if (!(Test-Path $LogPath)) 
{ 
    New-Item -Path $LogPath -ItemType Directory -Verbose 
} 

########## Creation of Logs Folder if does not exists ##############

if (!(Test-Path $LogFile)) 
{ 
    Write-Verbose "Creating $LogFile."
    $NewLogFile = New-Item $LogFile -Force -ItemType File
} 

######## A Function written to populate the log file. ##############

function LogMessage
{
    param($Message)
    
    ((Get-Date).ToString() + " - " + $Message) >> $LogFile;
}


######## Input text file which contains Machine Names and AD Groups. The input should have first row as heading MachineName ADGroup ##############

$devicedata = Get-Content "xxx\LocalAdminGroup.txt"

######## Module to add AD group to Local Administrator group for all given devices from the input file ##############

foreach($d in $devicedata)
{
   
    $d = $d.split(',')
    $ComputerName = $d[0]
    $adobj = $d[1]
       
    if(Test-Connection -BufferSize 32 -Count 1 -ComputerName $ComputerName -Quiet)
    {
        try
        {
            $userobj = Get-ADUser -LDAPFilter "(SAMAccountName=$adobj)"
            $grpobj = Get-ADGroup -LDAPFilter "(SAMAccountName=$adobj)"

            ################### Adds AD group to the Local Administrator Group ############################
            if($grpobj -ne $null)
            {
                $adgroup = $grpobj.Name
                $GroupName = Get-ADGroup $adgroup -Properties *
                $grpname = $GroupName.Name
                $Domain =  $GroupName.CanonicalName.Split("/")[0]        
                $LocalAdminGroup = [ADSI]"WinNT://$ComputerName/Administrators,group"
            
                $GroupObj = [ADSI]"WinNT://$Domain/$grpname,group"

                Try
                {
                    $LocalAdminGroup.Add($GroupObj.Path)
                    LogMessage("Group $Domain\$grpname has been aded to local admin group on computer $ComputerName")
                }
                Catch
                {
                    $Exception = ($_.Exception.Message).Split(":")[1].replace("account","group")
                
                    LogMessage("ADGroup: $Domain\$grpname Computer: $ComputerName $Exception")
                }
            }
            ################### Adds AD User to the Local Administrator Group ############################
            if($userobj -ne $null)
            {
                $aduser = $userobj.Name
                $ADUserName = Get-ADuser $aduser -Properties *
                $username = $ADUserName.Name
                $Domain =  $ADUserName.CanonicalName.Split("/")[0]        
                $LocalAdminGroup = [ADSI]"WinNT://$ComputerName/Administrators,group"
            
                $GroupObj = [ADSI]"WinNT://$Domain/$username,user"

                Try
                {
                    $LocalAdminGroup.Add($GroupObj.Path)
                    LogMessage("Group $Domain\$username has been aded to local admin group on computer $ComputerName")
                }
                Catch
                {
                    $Exception = ($_.Exception.Message).Split(":")[1].replace("account","user")
                
                    LogMessage("ADGroup: $Domain\$username Computer: $ComputerName $Exception")
                }  
            }
        }
        catch 
        {
             $Exception = ($_.Exception.Message).Split(":")[1]
             LogMessage($Exception)
        }
    }


    
}
