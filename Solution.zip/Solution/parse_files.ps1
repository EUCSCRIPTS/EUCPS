﻿################################################################################################################################################
###     FileName     : parse_files.ps1
###     Description  : Read two input files and find the device with only one monitor
###     Written By   : Venkatesh Sriram for Nexthink
###     Version      : 1.0
################################################################################################################################################

#### Read the input csv file from given location
$data_csv = import-csv  -path "C:\Temp\Nexthink\RemoteActionsSoftwareDeveloper\PowershellSoftwareDeveloper\data.csv"

#### Read the input xml file from given location
$Path = "C:\Temp\Nexthink\RemoteActionsSoftwareDeveloper\PowershellSoftwareDeveloper\data.xml"
 
#### load it into an XML object:
$xml = New-Object -TypeName XML
$xml.Load($Path)

#### Create an empty ordered Hash table/Dictionary to store the results
$one_monitor = [ordered]@{}


#### Parse the CSV file and append the hashtable with valid data
foreach($row in $data_csv)
{
    if(!($one_monitor.Contains($row.name)))
    {
        $one_monitor.Add($row.name,$row.last_ip_address)
    }
    else
    {
        $one_monitor.Remove($row.name)
    }
}

#### Parse the XML File and append the hashtable with device name which meets below criteria
Foreach ($XmlElement in $xml.investigation.body.r)
{
  if(($XmlElement.c1.childnodes.Count -eq 1) -and !($one_monitor.Contains($XmlElement.c0)))
  {
       $one_monitor.Add($XmlElement.c0,$XmlElement.c2) 
  }
  
}

#### Display the result
$one_monitor.GetEnumerator() | Select-Object @{Label='DeviceName';Expression={$_.Key}},@{Label='IP Address';Expression={$_.Value}}

############## Sample Output #####################
#  DeviceName IP Address   
#  ---------- ----------   
#  CHDB001    172.18.159.67
#  CHDB003    172.18.161.68
#  CHDB004    172.18.162.64
#  CHDB008    172.18.4.60  
#  CHDB009    172.18.157.60
#  CHDB010    172.18.160.72

################################################################################################################################################

