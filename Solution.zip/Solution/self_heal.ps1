﻿################################################################################################################################################
###     FileName     : self_heal.ps1
###     Description  : Script to Self Heal Tourist Info process on a Kiosk Device
###     Written By   : Venkatesh Sriram for Nexthink
###     Version      : 1.0
################################################################################################################################################

##### Creation of Log File 
 
    $LogPath = 'C:\Temp\crash'
  
    $TimeStamp = Get-Date -Format yyyyMMdd_HHmmss
 
    $LogFileName = '{0}.log' -f $TimeStamp
        
    $LogFile = Join-Path -Path $LogPath -ChildPath $LogFileName
    
    
##### Access Logging function from another file

. "C:\Temp\Logging.ps1"

##### Creation of Log Folder if does not exists 

if (!(Test-Path $LogPath)) 
{ 
    New-Item -Path $LogPath -ItemType Directory -Verbose 
} 

##### Creation of Log File if does not exists 

if (!(Test-Path $LogFile)) 
{ 
    Write-Verbose "Creating $LogFile."
    $NewLogFile = New-Item $LogFile -Force -ItemType File
} 


##### Create a scheduled task 
 

LogMessage("Checking for Self Heal Action on $env:ComputerName")

$task = Get-ScheduledTask -TaskName Selfheal -ErrorAction SilentlyContinue
if(!$task)
{
    Register-ScheduledTask -TaskName "Self-Heal" -xml (Get-Content "C:\Temp\Selfheal.xml" | Out-String) -Force
    LogMessage("Self Heal Action Task created successfully.")
}
else
{
    LogMessage("Self Heal Action Task already exits.")
}

##### Self heal (Before Restart) 

$count = 0
do{

    #check on the kiosk to detect if the process called TOURISTINFO.EXE (C:\Program Files\InfoPoint\TOURISTINFO.EXE) is up
    #and running.

    LogMessage("Checking the status of TOURISTINFO.EXE process.")
    $running = Get-Process notepad -ErrorAction SilentlyContinue

    if (!$running)
    {
        LogMessage("Process not running.")
        if($count -eq 1)
        {
            LogMessage("Restarting the Device")
            Restart-Computer -ComputerName $env:ComputerName
            break
        }
        LogMessage("Triggering the process TOURISTINFO.EXE.")
        Start-Process notepad

        LogMessage("Waiting for 2 minutes to check the status again")
        Start-Sleep -Seconds 120
    }
    $count +=1
} while ($count -lt 2)

################################################################################################################################################





