﻿################################################################################################################################################
###     FileName     : SH_AfterRestart.ps1
###     Description  : Script to Self Heal Tourist Info process on a Kiosk Device - To be included in the Scheduled Task
###     Written By   : Venkatesh Sriram for Nexthink
###     Version      : 1.0
################################################################################################################################################

###### Creation of Log File 
 
    $LogPath = 'C:\Temp\crash'
  
    $TimeStamp = Get-Date -Format yyyyMMdd_HHmmss
 
    $LogFileName = '{0}.log' -f $TimeStamp
        
    $LogFile = Join-Path -Path $LogPath -ChildPath $LogFileName
    
    
##### Creation of Log Folder if does not exists 

if (!(Test-Path $LogPath)) 
{ 
    New-Item -Path $LogPath -ItemType Directory -Verbose 
} 

##### Creation of Log File if does not exists

if (!(Test-Path $LogFile)) 
{ 
    Write-Verbose "Creating $LogFile."
    $NewLogFile = New-Item $LogFile -Force -ItemType File
} 

##### Access Logging function from another file 

. "C:\Temp\Logging.ps1"

##### Self heal (After Restart)

$count = 0
do{

    #check on the kiosk to detect if the process called TOURISTINFO.EXE (C:\Program Files\InfoPoint\TOURISTINFO.EXE) is up
    #and running after Restart.

    LogMessage("Checking the status of TOURISTINFO.EXE process.")
    $running = Get-Process notepad -ErrorAction SilentlyContinue

    if (!$running)
    {
        LogMessage("Process not running.")
        if($count -eq 1)
        {
            LogMessage("Informing the IT Support Team")
            Send-MailMessage -From 'kioskdeviceid@nexthink.com' -To 'kiosksupport@nexthink.com' -Subject '$env:Computer is malfunctioning' -SmtpServer 'smtpserver'

            LogMessage("Locking the Device")
            $xCmdString = {rundll32.exe user32.dll,LockWorkStation}
            Invoke-Command $xCmdString
            break
        }
        LogMessage("Triggering the process TOURISTINFO.EXE after a restart.")
        Start-Process notepad

        LogMessage("Waiting for 2 minutes to check the status again")
        Start-Sleep -Seconds 120
    }
    $count +=1
} while ($count -lt 2)

################################################################################################################################################
